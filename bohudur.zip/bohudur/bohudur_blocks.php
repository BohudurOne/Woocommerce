<?php
if (!defined('ABSPATH')) die('Direct Access Not Allowed!');

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Bohudur_Blocks_Integration extends AbstractPaymentMethodType {
    private $payment_gateway;
    protected $method_id = 'bohudur';

    public function initialize() {
        $this->settings = get_option('woocommerce_' . $this->method_id . '_settings', []);
        $this->payment_gateway = new Bohudur_Payment_Gateway();
    }

    public function is_active() {
        return $this->payment_gateway->is_available();
    }

    public function get_payment_method_script_handles() {
        $script_handle = 'bohudur-blocks-handler';
        $script_path = plugin_dir_url(__FILE__) . 'assets/js/checkout-handler.js';

        wp_register_script(
            $script_handle,
            $script_path,
            ['wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities', 'wp-i18n'],
            null,
            true
        );

        if (function_exists('wp_set_script_translations')) {
            wp_set_script_translations($script_handle, 'bohudur-gateway');
        }

        return [$script_handle];
    }

    public function get_payment_method_data() {
        return [
            'label' => $this->payment_gateway->get_title(),
        ];
    }
}
?>
