<?php
/*
Plugin Name: Bohudur
Plugin URI: https://bohudur.one/
Description: Receive payments via Bohudur for bKash, Rocket, Nagad, Upay.
Version: 1.0.1
Author: Bohudur
Author URI: https://bohudur.one/
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: bohudur-gateway
*/

defined('ABSPATH') or die('Direct access is not allowed.');

add_action('plugins_loaded', 'bohudur_init');
add_action('woocommerce_blocks_loaded', 'register_payment_method_types');
add_action('before_woocommerce_init', 'declare_cart_checkout_blocks_compatibility');

/**
 * Register Payment Method Types for Blocks Compatibility
 */
function register_payment_method_types() {
    if (!class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        return;
    }

    require_once plugin_dir_path(__FILE__) . 'bohudur_blocks.php';
    
    add_action('woocommerce_blocks_payment_method_type_registration', function($payment_method_registry) {
        $payment_method_registry->register(new Bohudur_Blocks_Integration());
    });
}

/**
 * Declare compatibility with Cart and Checkout blocks
 */
function declare_cart_checkout_blocks_compatibility() {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
}

/**
 * Initialize the Bohudur Gateway
 */
function bohudur_init() {
    if (!class_exists('WC_Payment_Gateway')) {
        add_action('admin_notices', 'bohudur_missing_woocommerce_notice');
        return;
    }

    require_once plugin_dir_path(__FILE__) . '/wc_gateway_bohudur_class.php';

    add_filter('woocommerce_payment_gateways', 'bohudur_add_gateway_class');
    add_action('woocommerce_after_checkout_form', 'bohudur_refresh_checkout_on_payment_methods_change');

    if (is_admin()) {
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'bohudur_plugin_action_links');
    }
}

/**
 * Display notice if WooCommerce is missing
 */
function bohudur_missing_woocommerce_notice() {
    echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('Bohudur requires WooCommerce to be installed and activated.', 'bohudur-gateway') . '</p></div>';
}

/**
 * Add Bohudur Payment Gateway
 */
function bohudur_add_gateway_class($methods) {
    if (!in_array('Bohudur_Payment_Gateway', $methods)) {
        $methods[] = 'Bohudur_Payment_Gateway';
    }
    return $methods;
}

/**
 * Plugin Action Links
 */
function bohudur_plugin_action_links($links) {
    $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=wc-settings&tab=checkout&section=bohudur')) . '">' . esc_html__('Settings', 'bohudur-gateway') . '</a>';
    $links[] = $settings_link;
    return $links;
}

/**
 * Ensure Checkout Refresh on Payment Method Change
 */
function bohudur_refresh_checkout_on_payment_methods_change() {
    wc_enqueue_js("
        jQuery(document).on('change', 'input[name^=payment_method]', function() {
            jQuery('body').trigger('update_checkout');
        });
    ");
}
?>
