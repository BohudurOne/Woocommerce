<?php
if (!defined('ABSPATH')) die('Direct Access Not Allowed!');
define('BOHUDUR',true);
require_once plugin_dir_path( __FILE__ ) . 'script.php';

class Bohudur_Payment_Gateway extends WC_Payment_Gateway {

    public function __construct() {
        $this->id = 'bohudur';
        $this->method_title = __('Bohudur', 'bohudur');
        $this->method_description = __('Pay via Bohudur using bKash, Rocket, Nagad, or Upay.', 'bohudur');
        $this->has_fields = true;
        
        $this->icon = plugin_dir_url(__FILE__) . 'assets/logo.png';
        $this->init_form_fields();
        $this->init_settings();

        $this->enabled = $this->get_option('enabled');
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->api_key = $this->get_option('api_key');
        $this->webhook_success_url = $this->get_option('webhook_success_url');
        $this->webhook_cancelled_url = $this->get_option('webhook_cancelled_url');
        $this->currency_rate = $this->get_option('currency_rate');
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
        add_action('woocommerce_api_wc_gateway_bohudur', [$this, 'handle_payment_result']);
    }

    public function init_form_fields() {
        $this->form_fields = [
            'enabled' => [
                'title' => __('Enable/Disable', 'bohudur'),
                'type' => 'checkbox',
                'label' => __('Enable Bohudur Payment Gateway', 'bohudur'),
                'default' => 'no',
            ],
            'title' => [
                'title' => __('Title', 'bohudur'),
                'type' => 'text',
                'description' => __('This controls the title visible at checkout.', 'bohudur'),
                'default' => __('Pay securely using Bohudur.', 'bohudur'),
                'desc_tip' => true,
            ],
            'description' => [
                'title' => __('Description', 'bohudur'),
                'type' => 'textarea',
                'description' => __('Description displayed during checkout.', 'bohudur'),
                'default' => __('Pay via Bohudur. Secure and easy payments.', 'bohudur'),
            ],
            'api_key' => [
                'title' => __('API Key', 'bohudur'),
                'type' => 'text',
                'description' => __('Your Bohudur API key.', 'bohudur'),
                'default' => '',
            ],
            'webhook_success_url' => [
                'title' => __('Webhook Success URL', 'bohudur'),
                'type' => 'url',
                'description' => __('You can keep it blank. Because it is not required for Woocommerce', 'bohudur'),
                'default' => '',
            ],
            'webhook_cancelled_url' => [
                'title' => __('Webhook Cancelled URL', 'bohudur'),
                'type' => 'url',
                'description' => __('You can keep it blank. Because it is not required for Woocommerce', 'bohudur'),
                'default' => '',
            ],
            'currency_rate' => [
                'title' => __('Currency Rate', 'bohudur'),
                'type' => 'number',
                'description' => __('You can use Bohudur Inbuilt Currency Converter by keeping it blank. But if you want to give custom rate of any currency then you can give. Like 1 USD = 130 BDT, you need to give 130.', 'bohudur'),
                'default' => '',
            ],
        ];
    }

    
    public function process_payment( $order_id ) {
        global $woocommerce;
        
        $order = wc_get_order( $order_id );
        $bohudur = new Bohudur( $this->api_key );
        
        $callback_url = $this->generate_callback_url($order);
        
        $data = [
            'fullname'       => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            'email'          => $order->get_billing_email(),
            'amount'         => (int)$order->get_total(),
            'redirect_url'   => $callback_url,
            'cancelled_url'  => wc_get_cart_url(),
            'return_type'    => 'Q',
            'metadata'       => [
                'order_id'  => $order->get_id(),
                'order_key' => $order->get_order_key(),
            ]
        ];
        
        if($order->get_currency() != 'BDT'){
            $data['currency'] = $order->get_currency();
        }
        
        if($this->currency_rate != '' && $this->currency_rate != 0){
            $data['currency_value'] = $this->currency_rate;
        }
        
        if($this->webhook_success_url != '' && $this->webhook_cancelled_url != ''){
            $data['webhook'] = [
                'success' => $this->webhook_success_url,
                'cancel'  => $this->webhook_cancelled_url
            ];
        }else if(!empty($this->webhook_success_url)){
            $data['webhook'] = [
                'success' => $this->webhook_success_url,
            ];
        }else if(!empty($this->webhook_cancelled_url)){
            $data['webhook'] = [
                'cancel' => $this->webhook_cancelled_url,
            ];
        }
        
        $response = $bohudur->sendRequest( $data );
        $result = json_decode($response,true);
        
        if (isset($result['responseCode']) && $result['responseCode'] == 200) {
            if (isset($result['payment_url'])) {
                if (isset($result['paymentkey'])) {
                    $payment_key = $result['paymentkey'];
                    $order->update_meta_data('_bohudur_payment_key', $payment_key);
                    $order->save();
                }
                
                $order->update_status( 'pending', __( 'Redirecting to Bohudur for payment.', 'bohudur' ) );
                wc_reduce_stock_levels( $order_id );
                $woocommerce->cart->empty_cart();
                
                return [
                    'result'   => 'success',
                    'redirect' => $result['payment_url'],
                ];
            } else {
                wc_add_notice( __( 'Payment gateway error. Please try again.', 'bohudur' ), 'error' );
                return [
                   'result' => 'failure',
                ];
            }
        } else {
            wc_add_notice( __( 'Payment request failed. Please contact support.'.$result['message'], 'bohudur' ), 'error' );
            return [
                'result' => 'failure',
            ];
        }
    }
    
    public function handle_payment_result() {
        if (isset($_GET['order_id']) && isset($_GET['payment_key'])) {
            $order_id = $_GET['order_id'];
            $payment_key = $_GET['payment_key'];
            
            $order = wc_get_order($order_id);
            $bohudur = new Bohudur($this->api_key);
            
            if ($order) {
                if ($order->get_status() === 'completed') {
                    exit("Something went wrong!");
                }
                
                if ($order->get_status() === 'failed') {
                    exit("Something went wrong!");
                }
                
                $response = $bohudur->executePayment($payment_key);
                $result = json_decode($response,true);
                
                if(isset($result['Status']) && $result['Status'] == 'EXECUTED'){
                    $stored_payment_key = $order->get_meta('_bohudur_payment_key');
                
                    if ($payment_key == $stored_payment_key) {
                        $this->update_order_bohudur($order,$result);
                    } else {
                        wp_redirect(wc_get_checkout_url());
                        exit;
                    }
                }else{
                    wp_redirect(wc_get_checkout_url());
                    exit;
                }
            } else {
                wp_redirect(wc_get_checkout_url());
                exit;
            }
        } else {
            wp_redirect(wc_get_checkout_url());
            exit;
        }
    }
    
    /**
     * function for updating payment status
     */
    public function update_order_bohudur($order,$result){
        if(!isset($result['responseCode'])){
            if(isset($result['Status']) && $result['Status'] == 'EXECUTED'){
                $payment_method = $result['MFS'];
                $amount = $result['Total Amount'];
                $transaction_id = $result['Transaction ID'];
                $sender_number = $result['Number'];
                
                if($this->is_order_digital_bohudur($order)){
                    $order->payment_complete();
                    $this->add_payment_success_note( $order, $result );
                    $order->update_status( 'completed', __( "Bohudur payment was successfully completed. Payment Method: {$payment_method}, Amount: {$amount}, Transaction ID: {$transaction_id}, Sender Number: {$sender_number}", 'bohudur-gateway' ) );
                    wp_redirect($this->get_return_url($order));
                    exit;
                }else{
                    $order->payment_complete();
                    $this->add_payment_success_note( $order, $result );
                    $order->update_status( 'processing', __( "Bohudur payment was successfully completed. Payment Method: {$payment_method}, Amount: {$amount}, Transaction ID: {$transaction_id}, Sender Number: {$sender_number}", 'bohudur-gateway' ) );
                    wp_redirect($this->get_return_url($order));
                    exit;
                }
            }else{
                $order->update_status( 'failed', __( 'Bohudur payment validation failed. Transaction status was not not COMPLETED. Please check it manually.', 'bohudur-gateway' ) );
                wp_redirect(wc_get_checkout_url());
                exit;
            }
        }else{
            $order->update_status('failed', __('Bohudur payment validation failed.'));
            wp_redirect(wc_get_checkout_url());
            exit;
        }
    }
    
    /**
     * add note to order
     */
    public function add_payment_success_note( $order_id, $payment_data ) {
        if ( ! $order || empty( $payment_data ) || ! is_array( $payment_data ) ) {
            return;
        }
        
        $note = "Payment Details:\n";
        foreach ( $payment_data as $key => $value ) {
            $note .= ucfirst( $key ) . ': ' . $value . "\n";
        }
        
        $order->add_order_note( $note, false );
    }
    
    /**
     * function to get is data virtual or not
     */
    public function is_order_digital_bohudur($order) {
        return $order && !array_filter($order->get_items(), fn($item) => !$item->get_product()?->is_virtual());
    }
    
    /**
     * this function generates callback url for woocommerce
     */
    public function generate_callback_url( $order ) {
        $callback_url = home_url('/index.php?wc-api=wc_gateway_bohudur&order_id=' . $order->get_id() . '&order_key=' . $order->get_order_key());
        return $callback_url;
    }
    
    /**
     * Override the icon output for the payment gateway.
     */
     public function get_icon() {
         $icon_html = sprintf(
            '<img src="%s" alt="%s" style="max-height: 48px; float: right; margin: -10px;" padding:0px; />',
            esc_url($this->icon),
            esc_attr($this->method_title)
         );
         return $icon_html;
     }
}
