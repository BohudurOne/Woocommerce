const paymentSettings = window.wc.wcSettings.getSetting('bohudur_data', {});
const paymentLabel = window.wp.htmlEntities.decodeEntities(paymentSettings.title) || 
                     window.wp.i18n.__('Bohudur Payment', 'bohudur-gateway');

const PaymentContent = () => {
    return window.wp.htmlEntities.decodeEntities(paymentSettings.description || '');
};

const BohudurPaymentBlock = {
    name: 'bohudur',
    label: paymentLabel,
    content: window.wp.element.createElement(PaymentContent, null),
    edit: window.wp.element.createElement(PaymentContent, null),
    canMakePayment: () => true,
    ariaLabel: paymentLabel,
    supports: {
        features: paymentSettings.supports || [],
    },
};

window.wc.wcBlocksRegistry.registerPaymentMethod(BohudurPaymentBlock);